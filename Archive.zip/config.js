const config = {
    GITHUB_TOKEN : 'token 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'
}


module.exports = config